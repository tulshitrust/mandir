import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inner-page-header',
  templateUrl: './inner-page-header.component.html',
  styleUrls: ['./inner-page-header.component.scss']
})
export class InnerPageHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
